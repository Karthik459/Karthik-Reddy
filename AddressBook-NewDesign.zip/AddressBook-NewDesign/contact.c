#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "populate.h"

void listContacts(AddressBook *addressBook) 
{
    // Sort contacts based on the chosen criteria
     
    for(int i=0;i<addressBook->contactCount;i++)
    {
	printf("%s\t ",addressBook->contacts[i].name);
	printf("%s\t ",addressBook->contacts[i].phone);
	printf("%s\n ",addressBook->contacts[i].email);

    }
}

void initialize(AddressBook *addressBook) {
    addressBook->contactCount = 0;
   // populateAddressBook(addressBook);
     //Load contcats from file during initialization
   //  saveContactsToFile(addressBook);
    
	FILE *fptr=fopen("file.csv","r");  //Open the in which the contacts are stored in read mode.

	if(fptr==NULL)   //In read mode if file does not exist it will return NULL. 
	{
	    printf("File not exist\n");
	
	}
	int count; //Declare one variable as int to store how many contacts are present in the file as count.
	    char contacts[200];  //Declare the string to store the data from file to structure.
	fscanf(fptr,"%d\n",&count);  //Read the count from the file and storing it to contactCount . 
	addressBook->contactCount=count;
	for(int i=0;i<addressBook->contactCount;i++)	//Run the loop till contactcount times to store the data from file to the structure.
	{
	    fscanf(fptr,"%[^\n]\n",contacts);   //Read the data of one line and store it to the structure.
	    char *token=strtok(contacts,",");  
	    strcpy(addressBook->contacts[i].name,token);
	    token=strtok(NULL,",");  
	    strcpy(addressBook->contacts[i].phone,token);
	    token=strtok(NULL,",");
	    strcpy(addressBook->contacts[i].email,token);


	}
	fclose(fptr);
	/*for(int i=0;i<addressBook->contactCount;i++)
	{
	    printf("%s %s %s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
	}
         */
    
    
    // Load contacts from file during initialization (After files)
    //loadContactsFromFile(addressBook);
}

void saveContactsToFile(AddressBook *addressBook)
{
    FILE *fp=fopen("file.csv","w");  //Open the file in write mode and save the created contacts to the file.

    
 


    fprintf(fp,"%d\n",addressBook->contactCount);

    for(int i=0;i<addressBook->contactCount;i++)   //To run the loop till contactCount times to save the contacts to the file
    {
    fprintf(fp,"%s,%s,%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }
    fclose(fp);   //After updating contacts close the file.

}


void createContact(AddressBook *addressBook)
{
   /* Define the logic for createContact */
    int k=addressBook->contactCount;
    if(k<100)
    {
    printf("Enter the Name\n");  //Enter the name which you want to create
    getchar();
    scanf("%[^\n]",addressBook->contacts[k].name);
    printf("Enter the phone\n");
    char number[11];
retry:
    scanf("%s",number);  //Enter the valid phone number 
    int i,count=0;
    for(i=0;number[i]!=0;i++)
    {
	if(number[i]>='0' && number[i]<='9')
	{
	    count++;
	}
	else
	{
	    printf("Please enter valid phonenumber");
	    goto retry;
	}
    }
    if(count!=10)
    {
	printf("Please Enter 10digit phone number");
	goto retry;
    }
    for(int j=0;j<=addressBook->contactCount;j++)
    {
	int ph=strcmp(addressBook->contacts[j].phone,number);
	    if(ph==0)
	    {
		printf("This is already saved.");
		goto retry;
	    }
    }
    strcpy(addressBook->contacts[k].phone,number);
    printf("Enter email\n");
    char temp[70];
retry1:
    scanf("%s",temp);  //Enter the valid email
    char ch='@';
    char ch1[]=".com";
    char ch2[]="@.com";

    char *ret=strchr(temp,ch);
    char *ret2=strstr(temp,ch1);
    if(!ret)
    {
	printf("invalid mail.Please enter valid mail\n");
	goto retry1;
    }
    if(!ret2)
    {
	printf("invalid mail.Please enter valid mail\n");
	goto retry1;
    }
    if(*(ret2+4)!='\0')
    {
	printf("Invalid email\n");
	goto retry1;
    }
    if(strstr(temp,ch2))
    {
	printf("Invalid mail.Please enter valid mail\n");
	goto retry1;
    
    }
    if(temp[0]=='@')
    {
	printf("Please enter some data before @\n");
	goto retry1;
    
    }
    for(int a=0;a<addressBook->contactCount;a++)
    {
	int b=strcmp(addressBook->contacts[a].email,temp);
	if(b==0)
	{
	    printf("email already exists\n");
	    goto retry1;
	}
    }
    strcpy(addressBook->contacts[k].email,temp);
}
k++;
addressBook->contactCount++;
}
void searchContact(AddressBook *addressBook) 
{
    /* Define the logic for search */
    int choise;  //Enter the choise 
    printf("1.name\n");
    printf("2.phone\n");
    printf("3.email\n");
    printf("Enter the choise\n");
    getchar();
    scanf("%d",&choise);

    switch(choise)
    {
	case 1:
	    printf("Enter the name\n");  //Enter the name which you what to search
	    getchar();
	    char str[70];
	    scanf("%[^\n]",str);
	    int d=0;
	    for(int i=0;i<addressBook->contactCount;i++)
	    {
		int result=strcmp(addressBook->contacts[i].name,str);
		if(result==0)
		{
		    d=1;
		    printf("%s\t",addressBook->contacts[i].name);
		    printf("%s\t",addressBook->contacts[i].phone);
		    printf("%s\n",addressBook->contacts[i].email);
		    break;
		}
		else
	        {
		    d=0;
		}

	    }
	    if(d==0)
	    {
		printf("Data not found please enter valid data\n");
	    }
	    break;
	case 2:
	    printf("Enter the phone\n");   //Enter the phone Which you want to print details.
		char number[11];
	    scanf("%s",number);
	    int a=0;
	    for(int i=0;i<addressBook->contactCount;i++)
	    {
		int result=strcmp(addressBook->contacts[i].phone,number);
		if(result==0)
		{
		  
		    a=1;
		    printf("%s\t",addressBook->contacts[i].name);
		    printf("%s\t",addressBook->contacts[i].phone);
		    printf("%s\n",addressBook->contacts[i].email);
		    break;
		}
		else
		{
		    a=0;
		}
	    }
	    if(a==0)
	    {
		printf("Data not found enter valid details\n");

	    }
	    break;
	case 3:
	    printf("Enter the mail\n");  //Enter the email which you want to search and print the details
	    char temp[50];
	    scanf("%s",temp);
	    int b=0;
	    for(int i=0;i<addressBook->contactCount;i++)
	    
	    {
		int result=strcmp(addressBook->contacts[i].email,temp);
		if(result==0)
		{
		    b=1;
		    printf("%s\t",addressBook->contacts[i].name);
		    printf("%s\t",addressBook->contacts[i].phone);
		    printf("%s\n",addressBook->contacts[i].email);
		    break;

		}
		else
		{
		    b=0;
		}

	    }
	    if(b==0)
	    {
		printf("Data not found enter valid details\n");
	    }
	    break;
	default:
	    printf("Invalid choise.\n");
}
}

void editContact(AddressBook *addressBook)
{
	/* Define the logic for Editcontact */
    printf("1.For edit contact through name\n");
    printf("2.For edit contact through phone\n");
    printf("3.For edit contact through email\n");
    int num;
    getchar();
    scanf("%d",&num);
    switch(num)
    {
	case 1:
	    printf("Enter the name which you what to edit\n");  //Enter the name 
	    char str1[30];
	    getchar();
	    scanf("%[^\n]",str1);
	    int flag=0;
	    int count=0;
	    for(int i=0;i<addressBook->contactCount;i++)
	    {
		int result=strcmp(addressBook->contacts[i].name,str1);

		if(result==0)
		{
		    flag=1;
		    printf("%d\n",i);
		    printf("%s\t",addressBook->contacts[i].name);
		    printf("%s\t",addressBook->contacts[i].phone);
		    printf("%s\n",addressBook->contacts[i].email);
		    count++;
		    
		}
	    }
	    if(flag==0)
	    {
		printf("Please Enter valid data\n");
	    }
	    if(count>=1)
	    {
		printf("please enter the choise\n");
		int n;
		getchar();
		scanf("%d",&n);
		printf("please enter the new name\n"); //Enter the new name.
		char str2[30];
		getchar();
		scanf("%[^\n]",str2);
		strcpy(addressBook->contacts[n].name,str2);
		printf("After the edit\n");
		printf("%s\t",addressBook->contacts[n].name);
		printf("%s\t",addressBook->contacts[n].phone);
		printf("%s\n",addressBook->contacts[n].email);

	    }
	    break;
	case 2:
	    printf("Enter the phone which you want to edit\n");
	    char str3[30];
	    getchar();
	    scanf("%s",str3);   //Enter the phone which you want to edit.
	    int out=0;
	    for(int i=0;i<addressBook->contactCount;i++)
	    {
		int result=strcmp(addressBook->contacts[i].phone,str3);
		if(result==0)
		{
		    out=1;
		    printf("Enter the new phone number\n");
		    char str4[30];
		    getchar();
		    scanf("%s",str4);  //Please Enter the new phone number
		    strcpy(addressBook->contacts[i].phone,str4);
		    printf("%s\t",addressBook->contacts[i].name);
		    printf("%s\t",addressBook->contacts[i].phone);
		    printf("%s\n",addressBook->contacts[i].email);
		}

	    }
	    if(out==0)
	    {
		printf("Invalid phone\n");
	    }
	    break;
	case 3:
	    printf("Enter the mail which you want to edit\n");
	    char str5[30];
	    getchar();
	    scanf("%s",str5);  //Enter the mail which you want to edit
	    getchar();
	    int o=0;
	    for(int i=0;i<addressBook->contactCount;i++)
	    {
		int result=strcmp(addressBook->contacts[i].email,str5);
		if(result==0)
		{
		    o=1;
		    printf("Enter the new mail\n");
		    char str6[30];
		    getchar();
		    scanf("%s",str6);  //Please enter the new mail
		    strcpy(addressBook->contacts[i].email,str6);
		    printf("%s\t",addressBook->contacts[i].name);
		    printf("%s\t",addressBook->contacts[i].phone);
		    printf("%s\n",addressBook->contacts[i].email);
		}

	    }
	    if(o==0)
	    {
		printf("Invalid email\n");
	    }
	    break;

    }


    
}

void deleteContact(AddressBook *addressBook)
{
	/* Define the logic for deletecontact */
    int choise;
    char str[30];
    char str1[30];
    char str2[30];

    printf("1.delete by using name\n");
    printf("2.delete by using phone\n");
    printf("3.delete by using email\n");
    scanf("%d",&choise);

    switch(choise) //Enter the choise by which you want to delete
    {
	case 1:
	    printf("Enter the name which you want to delete\n"); //Enter the name what to delete 
	    scanf("%s",str);
	    int flag=0;
	    for(int i=0;i<addressBook->contactCount;i++)
	    {
		int result=strcmp(addressBook->contacts[i].name,str);

		if(result==0)
		{
		    flag=1;
		    for(int j=i;j<addressBook->contactCount;j++)
		    {
			addressBook->contacts[j]=addressBook->contacts[j+1];
		    }
		    addressBook->contactCount--;

		}
		else
		{
		    flag=0;
		}
	

	    }
	    if(flag==0)
	    {
		printf("Enter valid details\n");
	    }
	    break;
	case 2:
	    printf("Enter the phone which you want to delete\n");//Enter the phone what to delete
	    scanf("%s",str1);
	    int a=0;
	    for(int i=0;i<addressBook->contactCount;i++)
	    {
		int result=strcmp(addressBook->contacts[i].phone,str1);

		if(result==0)
		    {
			a=1;
			for(int j=i;j<addressBook->contactCount;j++)
			{
			    addressBook->contacts[j]=addressBook->contacts[j+1];
			}
			addressBook->contactCount--;
		    }
		else
		{
		    a=0;

		}
	    }
	    if(a==0)
	    {
		printf("Please Enter the valid details\n");
	    }
	    break;
	case 3:
	    printf("Enter the email which you want to delete\n");  //Enter the email what to delete
	    scanf("%s",str2);
	    int b=0;
	    for(int i=0;i<addressBook->contactCount;i++)
	    {
		int result=strcmp(addressBook->contacts[i].email,str2);
		if(result==0)
		    {
			b=1;
			for(int j=i;j<addressBook->contactCount;j++)
			{
			    addressBook->contacts[j]=addressBook->contacts[j+1];
			}
			addressBook->contactCount--;
		    }
		else
		{
		    b=0;
		}

	    }
	    if(b==0)
	    {
		printf("Please Enter valid data\n");
	    }
	    break;
	default :
	    printf("Enter valid details\n");


    }

}
   
void saveAndExit(AddressBook *addressBook)
{
    int choise;  //Enter the choise
    printf("1.To save the contact\n"); //Save to the file and exit
    printf("2.To Exit without saving\n"); //Exit without saving to the file.
    scanf("%d",&choise);
    switch(choise)
    {
	case 1:
	    saveContactsToFile(addressBook);
	    exit(EXIT_SUCCESS);
	    break;
	case 2:
	    printf("The contact not saved to file\n");
	    exit(EXIT_SUCCESS);
	    break;
    }
}
















